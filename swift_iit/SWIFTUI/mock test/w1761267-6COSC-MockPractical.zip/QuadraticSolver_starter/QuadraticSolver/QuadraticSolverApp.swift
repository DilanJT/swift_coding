//
//  QuadraticSolverApp.swift
//  QuadraticSolver
//
//  Created by Philip Trwoga on 09/02/2023.
//

import SwiftUI

@main
struct QuadraticSolverApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
