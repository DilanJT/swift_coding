//
//  RightAngledTriangleApp.swift
//  RightAngledTriangle
//
//  Created by Dilan Jayamanne on 2023-03-18.
//

import SwiftUI

@main
struct RightAngledTriangleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
