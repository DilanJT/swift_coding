//
//  MortCalcApp.swift
//  MortCalc
//
//  Created by Dilan Jayamanne on 2023-03-23.
//

import SwiftUI

@main
struct MortCalcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
