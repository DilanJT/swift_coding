//
//  MortgageModel.swift
//  MortCalc
//
//  Created by Dilan Jayamanne on 2023-03-23.
//

import Foundation

class Mortgage: ObservableObject {
    @Published var monthlyPaymentText : String
    @Published var loadPeriodText : String
    @Published var interestRateText : String
    @Published var amountBurrowed : String
    
    init() {
        self.monthlyPaymentText = "1500"
        self.loadPeriodText = "25"
        self.interestRateText = "4"
        self.amountBurrowed = "300000"
    }
    
    func calculateMortgage() {
        guard
            let pmt = Double(self.monthlyPaymentText),
            let interest = Double(self.interestRateText),
            let period = Int(self.loadPeriodText) else {return}
        
        let r = interest / 100
        let A = (r / 12) + 1
        let n = period * 12
        let numerator = pmt * (pow(A, Double(Double(n))) - 1) * (pow(A, Double(-(n))))
        
        let P = numerator / (r / 12)
        
        self.amountBurrowed = String(format: "%.2f", P)
    }
    
    
}
