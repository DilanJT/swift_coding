//
//  ContentView.swift
//  MortCalc
//
//  Created by Dilan Jayamanne on 2023-03-23.
//

import SwiftUI

struct ContentView: View {
    
//    @State private var monthlyPaymentText : String = "1500"
//    @State private var loadPeriodText : String = "25"
//    @State private var interestRateText : String = "4"
//    @State private var amountBurrowed : String = "300000"
    
    @StateObject private var mortgageModel : Mortgage = Mortgage()
    
    var body: some View {
        ZStack{
            VStack{
                Image("home")
                    .resizable()
                    .scaledToFit()
                    .opacity(0.3)
                    .blur(radius: 5)
                Spacer()
            }
            
            
            VStack (spacing: 20){
                Text("Mortgage Calculator")
                    .font(.title)
                Label("Monthly Payment", systemImage: "sterlingsign.circle.fill")
                TextField("monthly payment", text: $mortgageModel.monthlyPaymentText)
                    .textFieldStyle(.roundedBorder)
                    .keyboardType(.numberPad)
                    .frame(height: 40)
                    .padding(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
                    .border(.blue)
                    
                    .onChange(of: mortgageModel.monthlyPaymentText) {newValue in
                        
                        self.mortgageModel.monthlyPaymentText = checkText(text: newValue)
                    }
                
                Label("Loan Period - years", systemImage: "clock.badge.questionmark")
                TextField("load period", text: $mortgageModel.loadPeriodText)
                    .keyboardType(.numberPad)
                    .frame(height: 40)
                    .padding(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
                    .border(.blue)
                    .onChange(of: mortgageModel.loadPeriodText) {newValue in
                        
                        self.mortgageModel.loadPeriodText = checkText(text: newValue)
                    }
                
                Label("interest rate", systemImage: "percent")
                TextField("interest", text: $mortgageModel.interestRateText)
                    .keyboardType(.numberPad)
                    .frame(height: 40)
                    .padding(EdgeInsets(top: 5, leading: 0, bottom: 5, trailing: 0))
                    .border(.blue)
                    .onChange(of: mortgageModel.interestRateText) {newValue in
                        
                        self.mortgageModel.interestRateText = checkText(text: newValue)
                    }
                
                Button {
                    mortgageModel.calculateMortgage()
                } label: {
                    Text("Calculate")
                }
                .buttonStyle(.borderedProminent)
                
                Text("Amount that can be burrowed £\(mortgageModel.amountBurrowed)")
                
                  
            }
            .multilineTextAlignment(.center)
        }
        .background(Color(.white))
    }
    
//    func calculateMortgage() {
//        guard
//            let pmt = Double(monthlyPaymentText),
//            let interest = Double(interestRateText),
//            let period = Int(loadPeriodText) else {return}
//
//        let r = interest / 100
//        let A = (r / 12) + 1
//        let n = period * 12
//        let numerator = pmt * (pow(A, Double(Double(n))) - 1) * (pow(A, Double(-(n))))
//
//        let P = numerator / (r / 12)
//
//        self.amountBurrowed = String(format: "%.2f", P)
//
//    }
    
    func checkText(text: String) -> String{
        
        var updatedString = text
        var dotCount = 0
        for d in text {
            if String(d) == "."
            { dotCount += 1 }
        }
        if dotCount >= 2 {
            // remove the last typed point
            updatedString = String(text.dropLast())
        }
        return updatedString
        
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
